package projects.dex.collecta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectaApplicationTests {

	@Test
	void contextLoads() {
	}

}
